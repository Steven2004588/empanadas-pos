<?php $__env->startSection('title', 'Nuevo Cliente'); ?>
<?php $__env->startSection('sidebar'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center mb-4">
    <a href="<?php echo e(route('admin.clientes.index')); ?>" class="btn btn-outline-secondary me-3">
        <i class="bi bi-arrow-left"></i>
    </a>
    <h4 class="mb-0"><i class="bi bi-person-plus"></i> Nuevo Cliente</h4>
</div>

<div class="card" style="max-width: 650px;">
    <div class="card-body p-4">
        <form action="<?php echo e(route('admin.clientes.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Tipo de Documento <span class="text-danger">*</span></label>
                    <select name="tipo_documento" class="form-select <?php $__errorArgs = ['tipo_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="cedula"           <?php echo e(old('tipo_documento') == 'cedula'           ? 'selected' : ''); ?>>Cédula</option>
                        <option value="tarjeta_identidad"<?php echo e(old('tipo_documento') == 'tarjeta_identidad'? 'selected' : ''); ?>>Tarjeta de Identidad</option>
                        <option value="pasaporte"        <?php echo e(old('tipo_documento') == 'pasaporte'        ? 'selected' : ''); ?>>Pasaporte</option>
                        <option value="nit"              <?php echo e(old('tipo_documento') == 'nit'              ? 'selected' : ''); ?>>NIT</option>
                    </select>
                    <?php $__errorArgs = ['tipo_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label fw-semibold">Número de Documento <span class="text-danger">*</span></label>
                    <input type="text" name="numero_documento"
                           class="form-control <?php $__errorArgs = ['numero_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('numero_documento')); ?>" placeholder="Ej: 1234567890">
                    <?php $__errorArgs = ['numero_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-12">
                    <label class="form-label fw-semibold">Nombre Completo <span class="text-danger">*</span></label>
                    <input type="text" name="nombre_completo"
                           class="form-control <?php $__errorArgs = ['nombre_completo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('nombre_completo')); ?>" placeholder="Ej: Juan Pérez">
                    <?php $__errorArgs = ['nombre_completo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-12">
                    <label class="form-label fw-semibold">Dirección</label>
                    <input type="text" name="direccion" class="form-control"
                           value="<?php echo e(old('direccion')); ?>" placeholder="Ej: Calle 10 # 5-20">
                </div>

                <div class="col-md-6">
                    <label class="form-label fw-semibold">Ciudad</label>
                    <input type="text" name="ciudad" class="form-control"
                           value="<?php echo e(old('ciudad')); ?>" placeholder="Ej: Bucaramanga">
                </div>

                <div class="col-md-6">
                    <label class="form-label fw-semibold">Teléfono</label>
                    <input type="text" name="telefono" class="form-control"
                           value="<?php echo e(old('telefono')); ?>" placeholder="Ej: 3001234567">
                </div>
            </div>

            <div class="d-flex gap-2 mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save"></i> Guardar
                </button>
                <a href="<?php echo e(route('admin.clientes.index')); ?>" class="btn btn-outline-secondary">
                    Cancelar
                </a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/empanadas-pos/resources/views/admin/clientes/create.blade.php ENDPATH**/ ?>