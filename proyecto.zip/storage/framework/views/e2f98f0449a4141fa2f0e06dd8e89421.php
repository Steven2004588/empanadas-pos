<?php $__env->startSection('title', 'Clientes'); ?>
<?php $__env->startSection('sidebar'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0"><i class="bi bi-people"></i> Clientes</h4>
    <a href="<?php echo e(route('admin.clientes.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Nuevo Cliente
    </a>
</div>

<div class="card">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Documento</th>
                    <th>Nombre</th>
                    <th>Ciudad</th>
                    <th>Teléfono</th>
                    <th class="text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($cliente->id); ?></td>
                    <td>
                        <span class="badge bg-secondary"><?php echo e(strtoupper(str_replace('_', ' ', $cliente->tipo_documento))); ?></span>
                        <?php echo e($cliente->numero_documento); ?>

                    </td>
                    <td><?php echo e($cliente->nombre_completo); ?></td>
                    <td><?php echo e($cliente->ciudad ?? '—'); ?></td>
                    <td><?php echo e($cliente->telefono ?? '—'); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(route('admin.clientes.edit', $cliente)); ?>"
                           class="btn btn-sm btn-warning">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <form action="<?php echo e(route('admin.clientes.destroy', $cliente)); ?>"
                              method="POST" class="d-inline"
                              onsubmit="return confirm('¿Eliminar este cliente?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center text-muted py-4">
                        No hay clientes registrados.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/empanadas-pos/resources/views/admin/clientes/index.blade.php ENDPATH**/ ?>